package com.example.beautystudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
